"""TEDDecor
Testing, Exceptions, and Decor

This is a easy to use library with testing, exceptions, and colorful text output. 
Dive in with minimal effort and get great results.
"""

__version__ = "1.1.0"
from . import Exceptions
from . import UnitTest
from .TED import TED
