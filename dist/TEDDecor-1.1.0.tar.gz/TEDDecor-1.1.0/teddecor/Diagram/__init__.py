"""Diagrm

This module is a collection of tools to draw data to the terminal window.
This module also is a collectoin of tools to draw svg's from data.
"""
