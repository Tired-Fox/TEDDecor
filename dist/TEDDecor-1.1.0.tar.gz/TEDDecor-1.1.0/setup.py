# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['teddecor',
 'teddecor.Diagram',
 'teddecor.Exceptions',
 'teddecor.TED',
 'teddecor.UnitTest',
 'teddecor.UnitTest.Asserts',
 'teddecor.Util']

package_data = \
{'': ['*'], 'teddecor.UnitTest': ['output/*']}

entry_points = \
{'console_scripts': ['TEDTest = teddecor.UnitTest.TEDTest:main']}

setup_kwargs = {
    'name': 'teddecor',
    'version': '1.1.0',
    'description': 'This is a easy to use library with testing, documentation, and docstring example tools. Dive in with minimal effort and get great results.',
    'long_description': None,
    'author': 'Tired-Fox',
    'author_email': 'zboehm104@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.7',
}


setup(**setup_kwargs)
