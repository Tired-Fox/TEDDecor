# All ideas for upcoming features

## Testing
1. Sub-test
1. Add ascii graphs and data charts with percentages as default output

## Exceptions
1. Chaining
1. Grouping
1. linking?

## diagramming
1. Terminal
   1. Graph
   2. Percentages
   3. Plots
      * Scatter plot
      * bar plot
2. SVG
   1. Graphs
   2. Charts
   3. percentages
   4. Terminal Screenshot

## TED
1. Gradients