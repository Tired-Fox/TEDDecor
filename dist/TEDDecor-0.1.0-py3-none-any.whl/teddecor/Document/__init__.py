"""Document

This module will generate documentation along with creating runnable example code in docstrings.
This module has an additional feature that tests that your code examples work with your current code. This way your examples stay up to date with your code. This is heavily inspired by rust
"""
