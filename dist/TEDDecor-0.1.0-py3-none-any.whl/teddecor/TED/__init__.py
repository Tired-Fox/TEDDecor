"""TED

TED is the name for the inline markup language for this library. This allows the user to customize strings and prettyprint different information to stdout.

Includes:

* parse -> returns formatted strings
* pprint -> parse TED markup strings and display them to stdout
* More to come...
"""
from .TED import *
