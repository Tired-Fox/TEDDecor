"""TED

TED is the name for the inline markdown parsing engine. This allows the user to customize strings and prettyprint the information to stdout.

Includes:

* TED Engine that parses and returns formatted strings
* Pretty print to auto parse TED markup strings and display them to stdout
* More to come...
"""
