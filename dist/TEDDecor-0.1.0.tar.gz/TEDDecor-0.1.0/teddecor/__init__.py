"""TEDDecor
Testing, Examples in Docstring, and Documentation with Decor

This is a easy to use library with testing, documentation, and docstring example tools. 
Dive in with minimal effort and get great results.
"""

__version__ = "0.1.0"
from . import UnitTest
