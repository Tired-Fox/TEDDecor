"""TED includes a parser to get literal strings from TED markup, along with a pprint
function that outputs the literal string from a TED markup.

Raises:
    MacroMissingError: If there is an incorrect macro or color specifier
    MacroError: If there is a general formatting error with a macro
"""
from __future__ import annotations
from typing import Pattern

from exception import *
from colors import *

# Tokens objects
# Regex objects
# Function to create stream of tokens
# Auto token comprehension

# RULES:
# - Styling is done with either * and _ for bold and underline or [] for macro
# - Macros contain color, hyperlink
# - Tokens:
#   - */bold token
#   - _/underline token
#   - foreground token
#   - background token
#   - Both fg and bg token
#   - Reset token
#   - hyperlink token
# - REGEX:
#   - Macro
#   - Bold
#   - Underline

SAMPLE = "\\[something]*text_"

RE_MACRO: Pattern = r"((\\*)\[(.*?)\])"

import re

pos = 0
length = len(SAMPLE)
for match in re.finditer(RE_MACRO, SAMPLE):
    full, escaped, macro = match.groups()
    start, end = match.span()

    if pos < start:
        print(SAMPLE[pos:start])

    if not escaped == "":
        _, remainder = divmod(len(escaped), 2)
        # print(escaped, remainder, 1 - remainder)

        if remainder:
            print("text =>", full)
        else:
            print("text =>", full[: len(escaped)])
            print("macro =>", full[len(escaped) :])

        pos = end

        continue

    print("macro =>", full)

    # print(full, escaped, macro, start, end)

    pos = end

if pos < len(SAMPLE):
    print("text =>", SAMPLE[pos:])
